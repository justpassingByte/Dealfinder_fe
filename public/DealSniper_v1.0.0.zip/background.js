/**
 * DealSniper - Background Service Worker
 * 
 * Currently an idle skeleton for Manifest V3 registration.
 * No active logic for feature-core-engine.
 * Future: May gain responsibilities in feature-analytics-layer (P3).
 */

// Allow content scripts (untrusted contexts) to read/write session storage
try {
  if (chrome.storage && chrome.storage.session) {
    chrome.storage.session.setAccessLevel({ accessLevel: 'TRUSTED_AND_UNTRUSTED_CONTEXTS' });
    console.log('[DealSniper] Session storage access level configured.');
  }
} catch (err) {
  console.error('[DealSniper] Failed to set storage access level:', err);
}

chrome.runtime.onInstalled.addListener(() => {
  console.log('[DealSniper] Extension installed successfully.');
});
