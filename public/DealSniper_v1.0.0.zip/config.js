/**
 * DealSniper — Configuration
 * 
 * Central config for all extension settings.
 * Edit this file to set your credentials.
 * 
 * ⚠️ This file is loaded as a content script (isolated world).
 *    It sets values on a global namespace that other scripts read.
 */

window.__dealsniper_config = {

  // ──────────────────────────────────────────────
  // Shopee Affiliate Program
  // ──────────────────────────────────────────────
  // Your Shopee Affiliate ID from https://affiliate.shopee.vn/
  // Leave empty to link directly to product pages (no affiliate tracking).
  AFFILIATE_ID: '17363560513',

  // ──────────────────────────────────────────────
  // Supabase (P3 — Analytics Layer, OPTIONAL)
  // ──────────────────────────────────────────────
  // Only needed if you enable feature-analytics-layer.
  // Get these from your Supabase project: https://app.supabase.com/
  SUPABASE_URL: '',
  SUPABASE_ANON_KEY: '',

  // ──────────────────────────────────────────────
  // Ranking Tuning
  // ──────────────────────────────────────────────
  // Adjust these weights (must sum to 1.0) to change ranking behavior.
  RANKING_WEIGHTS: {
    discount: 0.30,  // Price advantage weight
    rating: 0.25,  // Product quality weight
    shopTrust: 0.20,  // Seller reliability weight
    sold: 0.15,  // Popularity weight (log-normalized)
    engagement: 0.10   // Community signal weight
  },

  // Discount threshold for penalty (items above this % get score halved)
  DISCOUNT_PENALTY_THRESHOLD: 70,

  // ──────────────────────────────────────────────
  // Cache Settings
  // ──────────────────────────────────────────────
  CACHE_TTL_MINUTES: 10,  // How long cached results stay valid

  // ──────────────────────────────────────────────
  // Fetch Settings
  // ──────────────────────────────────────────────
  MAX_FETCH_ITERATIONS: 3,   // Hard ceiling (target 2 under normal conditions)
  FETCH_TIMEOUT_MS: 4000,    // Timeout per API request (3000-5000ms range)
  ITEMS_PER_PAGE: 60         // Shopee's items per page
};

console.log('[DealSniper] Config loaded.');
