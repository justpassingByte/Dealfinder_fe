/**
 * DealSniper — UI Overlay (Content Script)
 * 
 * Renders the full user-facing interface:
 * - "SNIPE BEST DEAL" trigger button with brand icon
 * - Skeleton loading cards
 * - Side drawer with ranked deals + "DEAL SNIPED" header
 * - Ranking Mode Selector (Best Value / Cheapest / Best Discount / Best Quality)
 * - Deal Quality Bar (visual score indicator)
 * - Quick Filters (price range, discount %)
 * - Sticky Best Deal (#1 always pinned at top)
 * - Affiliate URL construction at click time
 */

(function DealSniperUI() {
  'use strict';

  const EVENT_PREFIX = 'dealsniper:';
  const CONFIG = window.__dealsniper_config || {};
  const SKELETON_COUNT = 5;

  // ──────────────────────────────────────────────
  // State
  // ──────────────────────────────────────────────
  let drawerOpen = false;
  let isLoading = false;
  let currentKeyword = '';
  let allDeals = [];
  let allMetadata = null;

  // ──────────────────────────────────────────────
  // Brand Icon URL (from extension's own assets)
  // ──────────────────────────────────────────────
  function getIconUrl(size) {
    return chrome.runtime.getURL(`icons/icon${size}.png`);
  }

  // ──────────────────────────────────────────────
  // Utility: Format Vietnamese Dong
  // ──────────────────────────────────────────────
  function formatVND(amount) {
    if (!amount || amount <= 0) return '0₫';
    return new Intl.NumberFormat('vi-VN').format(Math.round(amount)) + '₫';
  }

  function formatSold(count) {
    if (count >= 1000) return (count / 1000).toFixed(1).replace('.0', '') + 'k';
    return count.toString();
  }

  function renderStars(rating) {
    const full = Math.floor(rating);
    const half = rating - full >= 0.5 ? 1 : 0;
    return '★'.repeat(full) + (half ? '½' : '') + '☆'.repeat(5 - full - half);
  }

  // ──────────────────────────────────────────────
  // Keyword Extraction
  // ──────────────────────────────────────────────
  function extractKeyword() {
    const params = new URLSearchParams(location.search);
    return params.get('keyword') || '';
  }

  // ──────────────────────────────────────────────
  // Affiliate URL Builder (at click time only)
  // ──────────────────────────────────────────────
  function buildAffiliateUrl(productUrl) {
    const affiliateId = CONFIG.AFFILIATE_ID || '';
    if (!affiliateId) return productUrl;
    const encoded = encodeURIComponent(productUrl);
    return `https://s.shopee.vn/an_redir?origin_link=${encoded}&affiliate_id=${affiliateId}`;
  }

  // ──────────────────────────────────────────────
  // Inject Styles
  // ──────────────────────────────────────────────
  function injectStyles() {
    if (document.getElementById('dealsniper-styles')) return;
    const link = document.createElement('link');
    link.id = 'dealsniper-styles';
    link.rel = 'stylesheet';
    link.href = chrome.runtime.getURL('styles.css');
    document.head.appendChild(link);
  }

  // ──────────────────────────────────────────────
  // 1. Control Panel (Replaces floating button)
  // ──────────────────────────────────────────────
  function createTriggerButton() {
    if (document.getElementById('dealsniper-cp')) return;

    const cp = document.createElement('div');
    cp.id = 'dealsniper-cp';
    cp.className = 'dealsniper-cp-card';
    
    cp.innerHTML = `
      <div class="dealsniper-cp-section">
        <label class="dealsniper-cp-label">🎯 Deal Mode</label>
        <select id="dealsniper-cp-mode" class="dealsniper-cp-select">
          <option value="best-value">⚡ Best Value</option>
          <option value="cheapest">💰 Cheapest</option>
          <option value="best-discount">🔥 Best Discount</option>
          <option value="best-quality">⭐ Best Quality</option>
        </select>
      </div>

      <div class="dealsniper-cp-section">
        <label class="dealsniper-cp-label">🔍 Scan Depth</label>
        <div class="dealsniper-cp-radio-group">
          <label class="dealsniper-cp-radio"><input type="radio" name="ds_depth" value="1" checked><span>Fast</span></label>
          <label class="dealsniper-cp-radio"><input type="radio" name="ds_depth" value="3"><span>Better</span></label>
          <label class="dealsniper-cp-radio"><input type="radio" name="ds_depth" value="5"><span>Deep</span></label>
        </div>
      </div>

      <button id="dealsniper-trigger" class="dealsniper-trigger-btn">
        🔥 SNIPE DEAL
      </button>
    `;

    document.body.appendChild(cp);

    // Bind trigger
    document.getElementById('dealsniper-trigger').addEventListener('click', handleTriggerClick);

    // Bind real-time mode change (rerank if already loaded)
    document.getElementById('dealsniper-cp-mode').addEventListener('change', (e) => {
      document.dispatchEvent(new CustomEvent(`${EVENT_PREFIX}change-mode`, {
        detail: { mode: e.target.value }
      }));
    });
  }

  function handleTriggerClick() {
    const keyword = extractKeyword();
    if (!keyword) {
      console.warn('[DealSniper UI] No keyword found in URL.');
      return;
    }

    const checkedRadio = document.querySelector('input[name="ds_depth"]:checked');
    const pages = checkedRadio ? parseInt(checkedRadio.value, 10) : 1;
    
    // Ensure mode is synced before fetching
    const mode = document.getElementById('dealsniper-cp-mode').value;
    document.dispatchEvent(new CustomEvent(`${EVENT_PREFIX}change-mode`, {
      detail: { mode }
    }));

    currentKeyword = keyword;
    isLoading = true;

    const btn = document.getElementById('dealsniper-trigger');
    if (btn) btn.disabled = true;

    openDrawerWithSkeletons(pages);

    document.dispatchEvent(new CustomEvent(`${EVENT_PREFIX}trigger`, {
      detail: { keyword, pages }
    }));
  }

  // ──────────────────────────────────────────────
  // 2. Side Drawer
  // ──────────────────────────────────────────────
  function createDrawer() {
    if (document.getElementById('dealsniper-drawer')) return;

    const overlay = document.createElement('div');
    overlay.id = 'dealsniper-drawer-overlay';
    overlay.className = 'dealsniper-drawer-overlay';
    overlay.addEventListener('click', closeDrawer);

    const drawer = document.createElement('div');
    drawer.id = 'dealsniper-drawer';
    drawer.className = 'dealsniper-drawer';

    // Header — "DEAL SNIPED" with brand icon
    const header = document.createElement('div');
    header.className = 'dealsniper-header';
    header.innerHTML = `
      <div class="dealsniper-header-left">
        <img class="dealsniper-header-icon" src="${getIconUrl(48)}" alt="DealSniper">
        <div>
          <div class="dealsniper-header-title">DEAL SNIPED</div>
          <div class="dealsniper-header-count" id="dealsniper-header-count">Searching...</div>
        </div>
      </div>
      <button class="dealsniper-close-btn" id="dealsniper-close">✕</button>
    `;

    // Filter Bar
    const filterBar = document.createElement('div');
    filterBar.className = 'dealsniper-filters';
    filterBar.id = 'dealsniper-filters';
    filterBar.innerHTML = `
      <div class="dealsniper-filter-group">
        <span class="dealsniper-filter-label">💰</span>
        <select class="dealsniper-filter-select" id="dealsniper-filter-price">
          <option value="all">All Prices</option>
          <option value="0-1000000">< 1M</option>
          <option value="1000000-3000000">1M - 3M</option>
          <option value="3000000-5000000">3M - 5M</option>
          <option value="5000000-10000000">5M - 10M</option>
          <option value="10000000-99999999">> 10M</option>
        </select>
      </div>
      <div class="dealsniper-filter-group">
        <span class="dealsniper-filter-label">🏷️</span>
        <select class="dealsniper-filter-select" id="dealsniper-filter-discount">
          <option value="all">All Sales</option>
          <option value="10">≥ 10%</option>
          <option value="20">≥ 20%</option>
          <option value="30">≥ 30%</option>
          <option value="50">≥ 50%</option>
        </select>
      </div>
      <button class="dealsniper-filter-reset" id="dealsniper-filter-reset">↺</button>
    `;

    // Sticky Best Deal container
    const stickyArea = document.createElement('div');
    stickyArea.className = 'dealsniper-sticky-deal';
    stickyArea.id = 'dealsniper-sticky-deal';
    stickyArea.style.display = 'none';

    // Body
    const body = document.createElement('div');
    body.className = 'dealsniper-body';
    body.id = 'dealsniper-body';

    // Disclosure
    const disclosure = document.createElement('div');
    disclosure.className = 'dealsniper-disclosure';
    disclosure.id = 'dealsniper-disclosure';
    disclosure.innerHTML = `
      <span class="dealsniper-disclosure-text">Links may include affiliate commission.</span>
      <button class="dealsniper-disclosure-dismiss" id="dealsniper-dismiss-disclosure">✕</button>
    `;

    drawer.appendChild(header);
    drawer.appendChild(filterBar);
    drawer.appendChild(stickyArea);
    drawer.appendChild(body);
    drawer.appendChild(disclosure);

    document.body.appendChild(overlay);
    document.body.appendChild(drawer);

    // Event listeners
    document.getElementById('dealsniper-close').addEventListener('click', closeDrawer);
    document.getElementById('dealsniper-dismiss-disclosure').addEventListener('click', dismissDisclosure);
    document.getElementById('dealsniper-filter-price').addEventListener('change', applyFilters);
    document.getElementById('dealsniper-filter-discount').addEventListener('change', applyFilters);
    document.getElementById('dealsniper-filter-reset').addEventListener('click', resetFilters);



    checkDisclosureDismissed();
  }

  function openDrawer() {
    createDrawer();
    drawerOpen = true;
    requestAnimationFrame(() => {
      const overlay = document.getElementById('dealsniper-drawer-overlay');
      const drawer = document.getElementById('dealsniper-drawer');
      if (overlay) overlay.classList.add('dealsniper-visible');
      if (drawer) drawer.classList.add('dealsniper-open');
    });
  }

  function closeDrawer() {
    drawerOpen = false;
    const overlay = document.getElementById('dealsniper-drawer-overlay');
    const drawer = document.getElementById('dealsniper-drawer');
    if (overlay) overlay.classList.remove('dealsniper-visible');
    if (drawer) drawer.classList.remove('dealsniper-open');
  }

  // ──────────────────────────────────────────────
  // 3. Skeleton Loading
  // ──────────────────────────────────────────────
  function openDrawerWithSkeletons(pages = 1) {
    openDrawer();
    const body = document.getElementById('dealsniper-body');
    const headerCount = document.getElementById('dealsniper-header-count');
    if (!body) return;

    if (headerCount) {
      headerCount.textContent = `Gathering up to ${pages * 60} items...`;
    }

    // Hide filters & sticky during loading
    const filters = document.getElementById('dealsniper-filters');
    const sticky = document.getElementById('dealsniper-sticky-deal');
    if (filters) filters.style.display = 'none';
    if (sticky) sticky.style.display = 'none';

    body.innerHTML = '';
    for (let i = 0; i < SKELETON_COUNT; i++) {
      const skeleton = document.createElement('div');
      skeleton.className = 'dealsniper-skeleton';
      skeleton.style.animationDelay = `${i * 0.08}s`;
      skeleton.innerHTML = `
        <div class="dealsniper-skeleton-img"></div>
        <div class="dealsniper-skeleton-content">
          <div class="dealsniper-skeleton-line"></div>
          <div class="dealsniper-skeleton-line"></div>
          <div class="dealsniper-skeleton-line"></div>
          <div class="dealsniper-skeleton-line"></div>
          <div class="dealsniper-skeleton-line"></div>
        </div>
      `;
      body.appendChild(skeleton);
    }
  }

  // ──────────────────────────────────────────────
  // 4. Filter Logic
  // ──────────────────────────────────────────────
  function getActiveFilters() {
    const priceVal = document.getElementById('dealsniper-filter-price')?.value || 'all';
    const discountVal = document.getElementById('dealsniper-filter-discount')?.value || 'all';
    return { priceVal, discountVal };
  }

  function filterDeals(deals) {
    const { priceVal, discountVal } = getActiveFilters();
    let filtered = [...deals];

    if (priceVal !== 'all') {
      const [min, max] = priceVal.split('-').map(Number);
      filtered = filtered.filter(d => d.price >= min && d.price <= max);
    }

    if (discountVal !== 'all') {
      const minDiscount = parseInt(discountVal);
      filtered = filtered.filter(d => d.discountPercent >= minDiscount);
    }

    return filtered;
  }

  function applyFilters() {
    if (allDeals.length === 0) return;
    const filtered = filterDeals(allDeals);
    renderDealCards(filtered, allMetadata, true);
  }

  function resetFilters() {
    const priceEl = document.getElementById('dealsniper-filter-price');
    const discountEl = document.getElementById('dealsniper-filter-discount');
    if (priceEl) priceEl.value = 'all';
    if (discountEl) discountEl.value = 'all';
    applyFilters();
  }

  // ──────────────────────────────────────────────
  // 5. Deal Quality Bar
  // ──────────────────────────────────────────────
  function getQualityClass(pct) {
    if (pct >= 80) return 'ds-q-excellent';
    if (pct >= 60) return 'ds-q-good';
    if (pct >= 40) return 'ds-q-fair';
    return 'ds-q-low';
  }

  function renderQualityBar(percentile) {
    if (!percentile || percentile <= 0) return '';
    const qClass = getQualityClass(percentile);
    return `
      <div class="dealsniper-quality-bar-wrap">
        <div class="dealsniper-quality-track">
          <div class="dealsniper-quality-fill ${qClass}" style="width: ${percentile}%"></div>
        </div>
        <span class="dealsniper-quality-pct ${qClass}">${percentile}%</span>
      </div>
    `;
  }

  // ──────────────────────────────────────────────
  // 6. Deal Cards (Progressive Rendering)
  // ──────────────────────────────────────────────
  function renderDealCards(topDeals, metadata, isFilterUpdate) {
    const body = document.getElementById('dealsniper-body');
    const countEl = document.getElementById('dealsniper-header-count');
    if (!body) return;

    // Show filters
    const filters = document.getElementById('dealsniper-filters');
    if (filters) filters.style.display = 'flex';

    body.innerHTML = '';

    if (!topDeals || topDeals.length === 0) {
      const sticky = document.getElementById('dealsniper-sticky-deal');
      if (sticky) sticky.style.display = 'none';

      body.innerHTML = `
        <div class="dealsniper-empty">
          <div class="dealsniper-empty-icon">🔍</div>
          <div class="dealsniper-empty-text">${isFilterUpdate ? 'No deals match your filters. Try adjusting.' : 'No better deals found for this search.'}</div>
        </div>
      `;
      if (countEl) countEl.textContent = isFilterUpdate ? 'No matches' : 'No deals found';
      return;
    }

    if (countEl) {
      const totalItems = metadata?.totalItems || topDeals.length;
      countEl.textContent = `Top ${topDeals.length} of ${totalItems} items`;
    }

    // Sticky Best Deal (#1 always visible at top)
    renderStickyDeal(topDeals[0]);

    // Render remaining cards
    const remainingDeals = topDeals.slice(1);
    remainingDeals.forEach((deal, index) => {
      const card = createDealCard(deal, index + 1);
      card.style.animationDelay = `${index * 0.06}s`;
      body.appendChild(card);
    });
  }

  // ──────────────────────────────────────────────
  // 7. Sticky Best Deal
  // ──────────────────────────────────────────────
  function renderStickyDeal(deal) {
    const stickyArea = document.getElementById('dealsniper-sticky-deal');
    if (!stickyArea || !deal) {
      if (stickyArea) stickyArea.style.display = 'none';
      return;
    }

    stickyArea.style.display = 'block';
    stickyArea.innerHTML = '';

    const label = document.createElement('div');
    label.className = 'dealsniper-sticky-label';
    label.textContent = '🏆 #1 BEST DEAL';

    const card = createDealCard(deal, 0);
    stickyArea.appendChild(label);
    stickyArea.appendChild(card);
  }

  // ──────────────────────────────────────────────
  // 8. Card Builder
  // ──────────────────────────────────────────────
  function createDealCard(deal, index) {
    const card = document.createElement('div');
    card.className = `dealsniper-card${index === 0 ? ' dealsniper-card-top' : ''}`;

    const discountClass = deal.penalized ? 'dealsniper-badge-discount-red' : 'dealsniper-badge-discount-green';
    const discountLabel = deal.discountPercent > 0 ? `-${deal.discountPercent}%` : '';

    card.innerHTML = `
      <img class="dealsniper-card-img" 
           src="${deal.image}" 
           alt="${escapeHtml(deal.name)}"
           loading="lazy"
           onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%2290%22 height=%2290%22><rect fill=%22%231a1a2e%22 width=%2290%22 height=%2290%22/><text x=%2245%22 y=%2250%22 text-anchor=%22middle%22 fill=%22%23666%22 font-size=%2230%22>📦</text></svg>'">
      <div class="dealsniper-card-content">
        <div class="dealsniper-card-title">${escapeHtml(deal.name)}</div>
        <div class="dealsniper-card-price-row">
          <span class="dealsniper-card-price">${formatVND(deal.price)}</span>
          ${deal.priceBeforeDiscount > deal.price ? `<span class="dealsniper-card-original-price">${formatVND(deal.priceBeforeDiscount)}</span>` : ''}
          ${discountLabel ? `<span class="dealsniper-badge-discount ${discountClass}">${discountLabel}</span>` : ''}
        </div>
        <div class="dealsniper-card-stats">
          <span class="dealsniper-stars">${renderStars(deal.ratingStar)}</span>
          <span class="dealsniper-divider">•</span>
          <span>${formatSold(deal.sold)} sold</span>
          <span class="dealsniper-divider">•</span>
          <span>Kho: ${formatSold(deal.stock)}</span>
        </div>
        <div class="dealsniper-card-tags">
          ${deal.shopName ? `<span class="ds-tag ds-tag-shop">🏪 ${escapeHtml(deal.shopName)}</span>` : ''}
          ${deal.shopLocation ? `<span class="ds-tag">📍 ${escapeHtml(deal.shopLocation)}</span>` : ''}
          ${deal.deliveryTime ? `<span class="ds-tag">🚚 ${escapeHtml(deal.deliveryTime)}</span>` : ''}
          ${deal.variationsCount > 1 ? `<span class="ds-tag">🎨 ${deal.variationsCount} mẫu</span>` : ''}
          ${deal.savingsAmount > 0 ? `<span class="ds-tag ds-tag-save">💰 Tiết kiệm ${formatVND(deal.savingsAmount)}</span>` : ''}
        </div>
        ${renderQualityBar(deal.percentile)}
        <a class="dealsniper-cta" href="#" data-product-url="${escapeHtml(deal.url)}" rel="noopener">
          View Deal →
        </a>
      </div>
    `;

    // Build affiliate URL at click time
    const ctaBtn = card.querySelector('.dealsniper-cta');
    if (ctaBtn) {
      ctaBtn.addEventListener('click', (e) => {
        e.preventDefault();
        const productUrl = ctaBtn.getAttribute('data-product-url');
        const finalUrl = buildAffiliateUrl(productUrl);
        console.log(`[DealSniper] Opening deal with affiliate: ${finalUrl}`);
        window.open(finalUrl, '_blank', 'noopener');
      });
    }

    return card;
  }

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  // ──────────────────────────────────────────────
  // 9. Top Pick Badge Injection
  // ──────────────────────────────────────────────
  function injectTopPickBadge(topDeal) {
    document.querySelectorAll('.dealsniper-top-pick-badge').forEach(el => el.remove());
    document.querySelectorAll('.dealsniper-top-pick-border').forEach(el => {
      el.classList.remove('dealsniper-top-pick-border');
    });

    if (!topDeal || !topDeal.itemid) return;

    const allLinks = document.querySelectorAll('a[href*="/product/"], a[href*="-i."]');
    for (const link of allLinks) {
      const href = link.getAttribute('href') || '';
      if (href.includes(`${topDeal.shopid}`) && href.includes(`${topDeal.itemid}`)) {
        const listingCard = link.closest('.shopee-search-item-result__item') || link.closest('[data-sqe="item"]') || link.parentElement;
        if (listingCard) {
          listingCard.style.position = 'relative';
          listingCard.classList.add('dealsniper-top-pick-border');

          const badge = document.createElement('div');
          badge.className = 'dealsniper-top-pick-badge';
          badge.textContent = '🔥 Top Pick';
          listingCard.appendChild(badge);
        }
        break;
      }
    }
  }

  // ──────────────────────────────────────────────
  // 10. Affiliate Disclosure
  // ──────────────────────────────────────────────
  async function checkDisclosureDismissed() {
    try {
      const result = await chrome.storage.local.get('dealsniper_disclosure_dismissed');
      if (result.dealsniper_disclosure_dismissed) {
        const el = document.getElementById('dealsniper-disclosure');
        if (el) el.style.display = 'none';
      }
    } catch (e) { /* ignore */ }
  }

  function dismissDisclosure() {
    const el = document.getElementById('dealsniper-disclosure');
    if (el) el.style.display = 'none';
    try {
      chrome.storage.local.set({ dealsniper_disclosure_dismissed: true });
    } catch (e) { /* ignore */ }
  }

  // ──────────────────────────────────────────────
  // 11. Event Listeners
  // ──────────────────────────────────────────────

  // Listen for ranked results
  document.addEventListener(`${EVENT_PREFIX}ranked-result`, (event) => {
    const { topDeals, metadata } = event.detail || {};
    console.log('[DealSniper UI] Received ranked results:', topDeals?.length, 'deals');
    console.log('[DealSniper UI] RAW RANKED ITEMS:', topDeals);

    isLoading = false;

    const btn = document.getElementById('dealsniper-trigger');
    if (btn) btn.disabled = false;

    allDeals = topDeals || [];
    allMetadata = metadata || {};

    // Sync mode dropdown in CP with ranking system result
    if (metadata?.mode) {
      const modeSelect = document.getElementById('dealsniper-cp-mode');
      if (modeSelect && modeSelect.value !== metadata.mode) {
        modeSelect.value = metadata.mode;
      }
    }

    // Apply current filters to new data
    const filtered = filterDeals(allDeals);
    renderDealCards(filtered, allMetadata, false);

    if (allDeals.length > 0) {
      injectTopPickBadge(allDeals[0]);
    }
  });

  // Listen for errors / zero results
  document.addEventListener(`${EVENT_PREFIX}fetch-result`, (event) => {
    const detail = event.detail || {};
    
    if (!detail.items || detail.items.length === 0) {
      if (isLoading) {
        isLoading = false;
        const btn = document.getElementById('dealsniper-trigger');
        if (btn) btn.disabled = false;
        
        renderDealCards([], { totalItems: 0 }, false);
        
        const countEl = document.getElementById('dealsniper-header-count');
        if (countEl) countEl.textContent = detail.action === 'FETCH_ERROR' 
          ? 'Network error. Please try again.' 
          : 'No deals found';
      }
    }
  });

  // ──────────────────────────────────────────────
  // 12. Initialization & SPA Navigation Handling
  // ──────────────────────────────────────────────
  function init() {
    if (!location.pathname.includes('/search')) {
      const cp = document.getElementById('dealsniper-cp');
      if (cp) cp.style.display = 'none';
      return;
    }

    injectStyles();
    createTriggerButton();
    const cp = document.getElementById('dealsniper-cp');
    if (cp) cp.style.display = 'flex';
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Handle Shopee SPA navigation (React URL changes without full reload)
  let lastUrl = location.href;
  setInterval(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      if (drawerOpen) closeDrawer(); // Close drawer on new search
      init();
    }
  }, 500);

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && drawerOpen) {
      closeDrawer();
    }
  });

})();
