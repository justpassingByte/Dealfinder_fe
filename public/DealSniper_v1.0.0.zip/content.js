/**
 * DealSniper - Content Controller (Isolated World)
 * 
 * Responsibilities per design doc §4.2:
 * - Request lock (concurrency mutex)
 * - Cache read/write (chrome.storage.session, 10-min TTL)
 * - Bridge dispatch/receive (CustomEvent with dealsniper: namespace)
 * - Inject script loader (web_accessible_resources)
 * - Downstream API (getCachedDeals)
 */

(function DealSniperContentController() {
  'use strict';

  // ──────────────────────────────────────────────
  // Constants
  // ──────────────────────────────────────────────
  const EVENT_PREFIX = 'dealsniper:';

  // ──────────────────────────────────────────────
  // State
  // ──────────────────────────────────────────────
  let requestLock = false;
  let injected = false;
  let injectorReady = false; // set true when inject.js signals readiness

  // ──────────────────────────────────────────────
  // 1. Inject Script Loader
  // ──────────────────────────────────────────────
  function injectMainWorldScript() {
    if (injected) return;
    try {
      const script = document.createElement('script');
      script.src = chrome.runtime.getURL('inject.js');
      script.onload = () => script.remove();
      (document.head || document.documentElement).appendChild(script);
      injected = true;
      console.log('[DealSniper] inject.js loaded into main world.');
    } catch (err) {
      console.error('[DealSniper] Failed to inject main world script:', err);
    }
  }

  /**
   * Wait for inject.js to signal readiness.
   * Returns true if ready, false if timeout.
   */
  function waitForInjectorReady(timeoutMs = 2000) {
    if (injectorReady) return Promise.resolve(true);
    return new Promise((resolve) => {
      const handler = () => {
        injectorReady = true;
        clearTimeout(tid);
        resolve(true);
      };
      document.addEventListener(`${EVENT_PREFIX}ready`, handler, { once: true });
      const tid = setTimeout(() => {
        document.removeEventListener(`${EVENT_PREFIX}ready`, handler);
        // If already injected, assume ready (fallback for edge case)
        if (injected) {
          injectorReady = true;
          resolve(true);
        } else {
          resolve(false);
        }
      }, timeoutMs);
    });
  }

  // Listen for inject.js readiness (may arrive before we start waiting)
  document.addEventListener(`${EVENT_PREFIX}ready`, () => {
    injectorReady = true;
    console.log('[DealSniper] inject.js reported ready.');
  }, { once: true });

  // ──────────────────────────────────────────────
  // 2. Bridge Protocol (CustomEvent)
  // ──────────────────────────────────────────────

  /**
   * Dispatch a fetch request to inject.js (main world).
   * Enforces concurrency lock.
   */
  async function triggerFetchDeals(keyword, pages = 1) {
    if (!keyword || typeof keyword !== 'string') {
      console.warn('[DealSniper] triggerFetchDeals called with invalid keyword.');
      return;
    }

    // Concurrency guard
    if (requestLock) {
      console.warn('[DealSniper] Fetch already in progress. Ignoring duplicate trigger.');
      return;
    }

    // Acquire lock
    requestLock = true;
    console.log(`[DealSniper] Dispatching fetch request for "${keyword}".`);

    // Ensure inject.js is loaded and ready
    injectMainWorldScript();
    const ready = await waitForInjectorReady();
    if (!ready) {
      console.error('[DealSniper] inject.js failed to initialize. Releasing lock.');
      requestLock = false;
      return;
    }

    // Dispatch request to main world
    document.dispatchEvent(new CustomEvent(`${EVENT_PREFIX}fetch-request`, {
      detail: { action: 'FETCH_DEALS', keyword: keyword.trim(), pages }
    }));
  }

  // ──────────────────────────────────────────────
  // 4. Bridge Listeners (receive from inject.js)
  // ──────────────────────────────────────────────

  // FETCH_PROGRESS
  document.addEventListener(`${EVENT_PREFIX}fetch-progress`, (event) => {
    const { itemsLoaded, iteration } = event.detail || {};
    console.log(`[DealSniper] Progress: ${itemsLoaded} items loaded (iteration ${iteration}).`);
  });

  // FETCH_COMPLETE
  document.addEventListener(`${EVENT_PREFIX}fetch-complete`, async (event) => {
    const { items, totalCount } = event.detail || {};
    if (!items) return;
    console.log(`[DealSniper] Content Script received fetch complete: ${items.length} items (total available: ${totalCount}).`);

    const keyword = event.detail.keyword || '';
    const pages = event.detail.pages || 1;

    // Release lock
    requestLock = false;

    // Re-emit as a unified result event for downstream consumers (ranking-system, ui-overlay)
    document.dispatchEvent(new CustomEvent(`${EVENT_PREFIX}fetch-result`, {
      detail: { action: 'FETCH_COMPLETE', items, totalCount, fromCache: false }
    }));
  });

  // FETCH_ERROR
  document.addEventListener(`${EVENT_PREFIX}fetch-error`, async (event) => {
    const { error, partialItems, keyword } = event.detail || {};
    console.error(`[DealSniper] Content Script received fetch error: ${error}`);

    // Release lock
    requestLock = false;

    // Re-emit for downstream consumers
    document.dispatchEvent(new CustomEvent(`${EVENT_PREFIX}fetch-result`, {
      detail: { action: 'FETCH_ERROR', error, items: partialItems || [], fromCache: false }
    }));
  });

  // ──────────────────────────────────────────────
  // 3. Expose API for downstream features
  // ──────────────────────────────────────────────
  // Downstream features (ranking-system, ui-overlay) can trigger via:
  //   document.dispatchEvent(new CustomEvent('dealsniper:trigger', { detail: { keyword } }))
  
  // Initial trigger
  document.addEventListener(`${EVENT_PREFIX}trigger`, (event) => {
    console.log('[DealSniper] Received trigger click from UI.');
    const { keyword, pages = 1 } = event.detail || {};
    if (keyword) {
      triggerFetchDeals(keyword, pages);
    }
  });

  // ──────────────────────────────────────────────
  // 6. Initialization
  // ──────────────────────────────────────────────
  console.log('[DealSniper] Content controller loaded on', location.hostname);

  // Pre-inject the main world script so it's ready for first trigger
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', injectMainWorldScript);
  } else {
    injectMainWorldScript();
  }

})();
