/**
 * DealSniper - Ranking System (Pure Function Module)
 * 
 * Supports 4 Preset Ranking Modes:
 *   ⚡ Best Value (default) — balanced deal quality
 *   💰 Cheapest            — lowest price first
 *   🔥 Best Discount       — biggest savings
 *   ⭐ Best Quality        — highest rated + trusted sellers
 * 
 * This is a pure, stateless, synchronous module.
 * No network calls, no DOM access, no chrome.* APIs.
 */

(function DealSniperRanking() {
  'use strict';

  // ──────────────────────────────────────────────
  // Constants
  // ──────────────────────────────────────────────
  const EVENT_PREFIX = 'dealsniper:';
  const TOP_N = 10;

  // ──────────────────────────────────────────────
  // Preset Modes — weight profiles
  // ──────────────────────────────────────────────
  const PRESETS = {
    'best-value': {
      label: '⚡ Best Value',
      weights: { discount: 0.30, rating: 0.20, sold: 0.20, price: 0.20, engagement: 0.10 }
    },
    'cheapest': {
      label: '💰 Cheapest',
      weights: { price: 0.55, discount: 0.20, rating: 0.10, sold: 0.10, engagement: 0.05 }
    },
    'best-discount': {
      label: '🔥 Best Discount',
      weights: { discount: 0.50, price: 0.20, sold: 0.15, rating: 0.10, engagement: 0.05 }
    },
    'best-quality': {
      label: '⭐ Best Quality',
      weights: { rating: 0.35, sold: 0.25, engagement: 0.15, discount: 0.15, price: 0.10 }
    }
  };

  let currentMode = 'best-value';
  let lastRawItems = [];  // Cache raw items for re-ranking

  const DISCOUNT_PENALTY_THRESHOLD = 70;
  const DISCOUNT_PENALTY_MULTIPLIER = 0.5;
  const ZERO_RATING_PENALTY = 0.8;

  // ──────────────────────────────────────────────
  // Statistical Outlier Rejection
  // ──────────────────────────────────────────────
  
  function calculateMedianPrice(items) {
    if (items.length === 0) return 0;
    const prices = items.map(i => i.price).sort((a, b) => a - b);
    const mid = Math.floor(prices.length / 2);
    return prices.length % 2 === 0
      ? (prices[mid - 1] + prices[mid]) / 2
      : prices[mid];
  }

  function removePriceOutliers(items) {
    const median = calculateMedianPrice(items);
    if (median <= 50000) return items; // Very cheap queries don't need heavy outlier filtering

    let lowerThreshold = 0;
    let upperThreshold = median * 7.0; // Drop placeholders like 99,999,999 VND

    if (median > 5000000) {
      lowerThreshold = median * 0.08; // High-end tech (20M). Drop < 1.6M
    } else if (median > 1000000) {
      lowerThreshold = median * 0.15; // Mid-range (2M). Drop < 300k
    } else if (median > 300000) {
      lowerThreshold = median * 0.20; // Regular goods (500k). Drop < 100k
    } else {
      lowerThreshold = median * 0.25; // Cheap goods (100k). Drop < 25k
    }

    return items.filter(item => {
      // Reject if price is an extreme outlier compared to the typical items in this exact search
      if (item.price < lowerThreshold || item.price > upperThreshold) {
        // console.log(`[DealSniper] Outlier Rejected: "${item.name}" (Price: ${item.price} vs Median: ${median})`);
        return false;
      }
      return true;
    });
  }

  // ──────────────────────────────────────────────
  // Dataset Statistics
  // ──────────────────────────────────────────────
  function computeDatasetStats(items) {
    let maxSold = 0;
    let maxLiked = 0;
    let maxPrice = 0;
    const prices = [];

    for (const item of items) {
      if (item.sold > maxSold) maxSold = item.sold;
      if (item.likedCount > maxLiked) maxLiked = item.likedCount;
      if (item.price > maxPrice) maxPrice = item.price;
      prices.push(item.price);
    }

    prices.sort((a, b) => a - b);
    const mid = Math.floor(prices.length / 2);
    const medianPrice = prices.length % 2 === 0
      ? (prices[mid - 1] + prices[mid]) / 2
      : prices[mid];

    return {
      maxLogSold: Math.log(maxSold + 1),
      maxLogLiked: Math.log(maxLiked + 1),
      maxPrice,
      medianPrice,
      totalItems: items.length
    };
  }

  // ──────────────────────────────────────────────
  // Scoring Engine
  // ──────────────────────────────────────────────
  function scoreItem(item, stats, weights) {
    // Normalize factors to 0–1 range
    const discountFactor = (item.discountPercent || 0) / 100;
    const ratingFactor = (item.ratingStar || 0) / 5.0;
    
    const soldFactor = stats.maxLogSold > 0
      ? Math.log((item.sold || 0) + 1) / stats.maxLogSold
      : 0;
    
    const engagementFactor = stats.maxLogLiked > 0
      ? Math.log((item.likedCount || 0) + 1) / stats.maxLogLiked
      : 0;

    // Price factor: inverse — cheaper = higher score
    const priceFactor = stats.maxPrice > 0
      ? 1 - (item.price / stats.maxPrice)
      : 0;

    // Weighted raw score using active preset weights
    const rawScore = (discountFactor   * (weights.discount || 0))
                   + (ratingFactor     * (weights.rating || 0))
                   + (soldFactor       * (weights.sold || 0))
                   + (engagementFactor * (weights.engagement || 0))
                   + (priceFactor      * (weights.price || 0));

    // Penalties
    let penaltyMultiplier = 1.0;
    let penalized = false;
    let penaltyReason = '';

    if (item.discountPercent > DISCOUNT_PENALTY_THRESHOLD) {
      penaltyMultiplier *= DISCOUNT_PENALTY_MULTIPLIER;
      penalized = true;
      penaltyReason = `Discount ${item.discountPercent}% > ${DISCOUNT_PENALTY_THRESHOLD}%`;
    }

    if (item.ratingStar === 0) {
      penaltyMultiplier *= ZERO_RATING_PENALTY;
      penalized = true;
      penaltyReason += (penaltyReason ? '; ' : '') + 'No ratings';
    }

    const finalScore = rawScore * penaltyMultiplier;
    const savingsAmount = Math.max(0, (item.priceBeforeDiscount || item.price) - item.price);

    return {
      ...item,
      score: Math.round(finalScore * 10000) / 10000,
      penalized,
      penaltyReason,
      savingsAmount
    };
  }

  /**
   * Main ranking function. Pure, stateless, synchronous.
   * @param {NormalizedItem[]} items
   * @param {string} mode - Preset mode key
   */
  function rankDeals(items, mode) {
    if (!items || items.length === 0) {
      return {
        topDeals: [], allScored: [],
        metadata: { totalItems: 0, maxScore: 0, medianPrice: 0, mode: mode || currentMode }
      };
    }

    const startTime = performance.now();
    const activeMode = mode || currentMode;
    const weights = PRESETS[activeMode]?.weights || PRESETS['best-value'].weights;

    // Smart Outlier Rejection: Drop items that are insanely cheap compared to the median search intent.
    const cleanItems = removePriceOutliers(items);

    const stats = computeDatasetStats(cleanItems);
    const allScored = cleanItems.map(item => scoreItem(item, stats, weights));

    // Sort by score descending, tiebreakers
    allScored.sort((a, b) => {
      if (b.score !== a.score) return b.score - a.score;
      if (b.ratingStar !== a.ratingStar) return b.ratingStar - a.ratingStar;
      return b.sold - a.sold;
    });

    const topDeals = allScored.slice(0, TOP_N).map((item, index) => ({
      ...item,
      rank: index + 1,
      percentile: Math.round(((stats.totalItems - (index + 1)) / stats.totalItems) * 100)
    }));

    const maxScore = allScored.length > 0 ? allScored[0].score : 0;
    const elapsed = Math.round((performance.now() - startTime) * 100) / 100;
    
    console.log(`[DealSniper] Ranked ${items.length} items in ${elapsed}ms (mode: ${activeMode}). Top score: ${maxScore}`);

    return {
      topDeals,
      allScored,
      metadata: {
        totalItems: stats.totalItems,
        maxScore,
        medianPrice: stats.medianPrice,
        processingTimeMs: elapsed,
        mode: activeMode
      }
    };
  }

  // ──────────────────────────────────────────────
  // Re-rank with a different mode (called by UI)
  // ──────────────────────────────────────────────
  function rerank(mode) {
    if (!PRESETS[mode]) {
      console.warn(`[DealSniper] Unknown ranking mode: ${mode}`);
      return;
    }
    currentMode = mode;
    
    if (lastRawItems.length === 0) {
      console.warn('[DealSniper] No items to re-rank.');
      return;
    }

    console.log(`[DealSniper] Re-ranking ${lastRawItems.length} items with mode: ${PRESETS[mode].label}`);
    const result = rankDeals(lastRawItems, mode);

    document.dispatchEvent(new CustomEvent(`${EVENT_PREFIX}ranked-result`, {
      detail: result
    }));

    logTopDeals(result);
  }

  // ──────────────────────────────────────────────
  // Console Display
  // ──────────────────────────────────────────────
  function logTopDeals(result) {
    console.log(`[DealSniper] 🏆 Top ${result.topDeals.length} Deals (${PRESETS[currentMode]?.label || currentMode}):`);
    const displayData = result.topDeals.map((d, i) => ({
      '#': i + 1,
      'Tên': d.name.substring(0, 35) + '...',
      'Điểm': d.score.toFixed(2),
      'Giá': d.price.toLocaleString('vi-VN') + ' đ',
      'Sale': '-' + d.discountPercent + '%',
      'Đã bán': d.sold
    }));
    console.table(displayData);
  }

  // ──────────────────────────────────────────────
  // Integration: Listen for core-engine results
  // ──────────────────────────────────────────────
  document.addEventListener(`${EVENT_PREFIX}fetch-result`, (event) => {
    const { action, items } = event.detail || {};

    if (action === 'FETCH_COMPLETE' && items && items.length > 0) {
      // Cache raw items for re-ranking when user switches mode
      lastRawItems = items;

      console.log(`[DealSniper] Ranking ${items.length} items (mode: ${PRESETS[currentMode].label})...`);
      const result = rankDeals(items, currentMode);

      document.dispatchEvent(new CustomEvent(`${EVENT_PREFIX}ranked-result`, {
        detail: result
      }));

      logTopDeals(result);

    } else if (action === 'FETCH_ERROR') {
      const partialItems = items || event.detail.partialItems || [];
      if (partialItems.length > 0) {
        lastRawItems = partialItems;
        const result = rankDeals(partialItems, currentMode);
        document.dispatchEvent(new CustomEvent(`${EVENT_PREFIX}ranked-result`, {
          detail: result
        }));
      }
    }
  });

  // Listen for mode change requests from UI
  document.addEventListener(`${EVENT_PREFIX}change-mode`, (event) => {
    const { mode } = event.detail || {};
    if (mode) rerank(mode);
  });

  // ──────────────────────────────────────────────
  // Expose for testing / direct invocation
  // ──────────────────────────────────────────────
  window.__dealsniper_ranking = { rankDeals, rerank, PRESETS };

  console.log('[DealSniper] Ranking system initialized with preset modes:', Object.keys(PRESETS).join(', '));

})();
