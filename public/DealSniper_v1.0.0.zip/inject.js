/**
 * DealSniper - Main World Fetcher (Main World Context)
 * 
 * Responsibilities per design doc §4.3 & §4.4:
 * - Origin verification (shopee.vn only)
 * - Sequential fetch loop with dynamic pagination
 * - AbortController timeouts (3-5s per request)
 * - Exactly-once retry per failed offset
 * - Data normalization (raw API → NormalizedItem)
 * - DOM fallback parser
 * - Progress/complete/error event emission via CustomEvent bridge
 */

(function DealSniperInjector() {
  'use strict';

  // ──────────────────────────────────────────────
  // Origin Verification (Security Boundary)
  // ──────────────────────────────────────────────
  if (!location.hostname.includes('shopee.vn')) {
    console.warn('[DealSniper] Origin check failed. Not on shopee.vn. Aborting.');
    return;
  }

  // ──────────────────────────────────────────────
  // Constants
  // ──────────────────────────────────────────────
  const EVENT_PREFIX = 'dealsniper:';
  const SEARCH_API = 'https://shopee.vn/api/v4/search/search_items';
  const FETCH_LIMIT = 60;
  const MAX_ITERATIONS = 1;    // Only 1 page (60 items is enough for top 10)
  const TIMEOUT_MS = 6000;     // 6 seconds - Shopee's security layer adds overhead
  const IMAGE_CDN_BASE = 'https://down-vn.img.susercontent.com/file/';
  const PRICE_DIVISOR = 100000; // Shopee returns price * 100000

  // ──────────────────────────────────────────────
  // Utility: Randomized Delay
  // ──────────────────────────────────────────────
  function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  function randomBackoff() {
    return 200 + Math.random() * 300; // 200-500ms
  }

  // ──────────────────────────────────────────────
  // Data Normalization (Subtask 1.4)
  // ──────────────────────────────────────────────

  /**
   * Transform a raw Shopee API item into NormalizedItem schema.
   * Missing fields default to 0 or "".
   * 
   * @param {Object} raw - Raw item from Shopee API response
   * @returns {Object} NormalizedItem
   */
  function normalizeItem(raw) {
    // ISSUE-5 FIX: Unwrap item_basic if Shopee nests the data
    const item = raw.item_basic || raw;

    const itemid = item.itemid || 0;
    const shopid = item.shopid || 0;
    const imageHash = item.image || (item.images && item.images[0]) || '';

    return {
      itemid,
      shopid,
      name: item.name || '',
      price: (item.price || 0) / PRICE_DIVISOR,
      priceMin: (item.price_min || item.price || 0) / PRICE_DIVISOR,
      priceMax: (item.price_max || item.price || 0) / PRICE_DIVISOR,
      priceBeforeDiscount: (item.price_before_discount || item.price || 0) / PRICE_DIVISOR,
      discountPercent: item.raw_discount || 0,
      image: imageHash ? `${IMAGE_CDN_BASE}${imageHash}` : '',
      sold: item.historical_sold || item.sold || 0,
      ratingStar: item.item_rating?.rating_star || 0,
      shopRating: item.shop_rating || 0,
      likedCount: item.liked_count || 0,
      stock: item.stock || 0,
      shopLocation: item.shop_location || '',
      shopName: item.shop_name || '',
      deliveryTime: item.estimated_delivery_time?.estimated_delivery_time_text || '',
      variationsCount: item.tier_variations?.reduce((total, tier) => total + (tier.options?.length || 0), 0) || 0,
      url: `https://shopee.vn/product/${shopid}/${itemid}`
    };
  }

  /**
   * Smart accessory filter
   * Excludes common accessory spam unless the user actually searched for those accessories.
   */
  function isRelevantToQuery(title, query) {
    if (!title || !query) return true;
    
    const titleLower = title.toLowerCase();
    const queryLower = query.toLowerCase();
    
    // 1. Exact words that need boundaries to avoid matching inside legitimate words
    const exactKeywords = [
      'ốp', 'case', 'vỏ', 'dán', 'ppf', 'skin', 'decal', 'hub', 'box', 'túi', 
      'rỗng', 'trống', 'xác', 'lỗi', 'feet', 'ngàm', 'switch', 'click'
    ];
    
    // 2. Phrases/words that are safe to match anywhere in the string
    const phraseKeywords = [
      'ốp lưng', 'bao da', 'kính cường lực', 'cường lực', 'miếng dán',
      'chống sốc', 'trường hợp', 'điện thoại cứng', // "trường hợp" = machine translation of "case"
      'cáp', 'sạc', 'củ sạc', 'dây sạc', 'cable', 'charger', 'adapter', 'đầu chuyển',
      'phụ kiện', 'khung', 'viền', 'lens', 'bảo vệ', 'linh kiện', 'mặt kính', 'màn thay',
      'tai nghe', 'headphone', 'earphone', 'airpods', 'loa', 
      'mô hình', 'dummy', 'mockup',
      'dây đeo', 'chân đế', 'giá đỡ', 'quạt tản nhiệt', 'tản nhiệt',
      'mắt cam', 'bảo vệ cam', 'viền cam', 'bọc cam', 'che cam', 'kính cam', 'cam vũ trụ',
      'chỉ hộp', 'chỉ có hộp', 'hư hỏng', 'thanh lý',
      'receiver', 'đầu thu', 'griptape', 'grip tape', 'chống trượt', 'cao su', 'nhựa'
    ];
    
    // Combine for the "did user search for accessory?" check
    const allKeywords = [...exactKeywords, ...phraseKeywords];
    const isSearchingForAccessory = allKeywords.some(kw => queryLower.includes(kw));
    
    if (!isSearchingForAccessory) {
      // Check Phrase Keywords (simple includes is enough for multi-word phrases)
      const isPhraseAccessory = phraseKeywords.some(kw => titleLower.includes(kw));
      if (isPhraseAccessory) return false;
      
      // Check Exact Keywords (needs word boundary)
      const isExactAccessory = exactKeywords.some(kw => {
        const regex = new RegExp(`(?:^|\\s|[.,\\-_+\\(\\[])\\s*${kw}\\s*(?:$|\\s|[.,\\-_+\\)\\]])`, 'i');
        return regex.test(titleLower);
      });
      
      if (isExactAccessory) return false;
    }
    
    // 3. Strict Relevance Filter (Brand/Model Mismatch)
    // Shopee injects competitor ads (Search 'ATK F1' -> returns 'Daeru' or 'ATK X1').
    // We identify "model numbers" (combinations of letters and numbers like 'f1', 'x1', 'g102').
    // If the user's query contains a model number, the product title MUST contain that model number.
    const queryTokens = queryLower.split(/[\s,.\-+]+/).filter(w => w.trim().length > 0);
    const modelTokens = queryTokens.filter(t => /[a-z]/.test(t) && /[0-9]/.test(t)); // e.g. f1, r1, g102

    if (modelTokens.length > 0) {
      // If user specified an exact model number like "f1", title MUST contain ALL of them 
      // (so "atk f1 pro" query won't match "atk f1" unless "f1 pro" logic applies, but 'pro' isn't alphanumeric).
      // Wait, 'pro' doesn't have numbers. So modelTokens is just ['f1'].
      const hasModels = modelTokens.every(token => titleLower.includes(token));
      if (!hasModels) return false;
    } else {
      // Fallback for non-alphanumeric searches (e.g. 'chuột logitech')
      const commonViWords = [
        'chuột', 'bàn', 'phím', 'tai', 'nghe', 'điện', 'thoại', 'máy', 'tính', 'màn', 'hình', 
        'không', 'dây', 'có', 'ốp', 'lưng', 'bao', 'da', 'kính', 'cường', 'lực', 'cáp', 'sạc',
        'quần', 'áo', 'giày', 'dép', 'túi', 'xách', 'balo', 'nam', 'nữ', 'trẻ', 'em', 'chính', 'hãng',
        'chơi', 'game', 'giá', 'rẻ', 'cao', 'cấp', 'cơ', 'cầm', 'tay', 'chuẩn', 'bluetooth', 'gaming'
      ];
      const highSignalTokens = queryTokens.filter(t => !commonViWords.includes(t) && t.length > 2);
      
      if (highSignalTokens.length > 0) {
        const isMatch = highSignalTokens.some(token => titleLower.includes(token));
        if (!isMatch) return false;
      }
    }

    return true;
  }

  /**
   * Validate that a normalized item has critical fields and passes relevance checks.
   * Logs warnings for items missing essential data or flagged as junk.
   */
  function isValidItem(item, query = '') {
    if (!item.itemid || !item.price) {
      return false;
    }
    
    // 1. Smart Keyword Filter
    if (!isRelevantToQuery(item.name, query)) {
      return false;
    }

    // 2. Variant Trap Trap Filter
    // Shopee sellers often add a 20k accessory to a 20M phone to game the search rank (Price gap 1000%).
    // If we detect max variant price is vastly larger than min variant price, we drop it.
    if (item.priceMin > 0 && item.priceMax > 0 && item.priceMax !== item.priceMin) {
      const priceGapRatio = item.priceMax / item.priceMin;
      // If gap is more than 400% (4x) and item is not extremely cheap natively
      if (priceGapRatio >= 4.0) {
        // console.warn(`[DealSniper] Filtered variant spam trap (${priceGapRatio.toFixed(1)}x gap):`, item.name);
        return false;
      }
    }
    
    return true;
  }

  // ──────────────────────────────────────────────
  // DOM Fallback Parser (Subtask 1.5)
  // ──────────────────────────────────────────────

  /**
   * Scrape product items from the visible page DOM.
   * Last-resort fallback when API fetch fails after retry.
   * Outputs the same NormalizedItem schema.
   */
  function parseDOMFallback(keyword) {
    console.log('[DealSniper] Attempting DOM fallback extraction...');
    const items = [];

    try {
      // Primary selector for Shopee search result items
      const elements = document.querySelectorAll('.shopee-search-item-result__item');
      
      if (elements.length === 0) {
        console.warn('[DealSniper] DOM fallback: No .shopee-search-item-result__item elements found.');
        return items;
      }

      elements.forEach((el, index) => {
        try {
          // Extract product link
          const linkEl = el.querySelector('a[href*="/product/"]') || el.querySelector('a[data-sqe]');
          const href = linkEl?.getAttribute('href') || '';
          
          // Parse shopid/itemid from URL: /product/{shopid}/{itemid} or /{slug}-i.{shopid}.{itemid}
          let itemid = 0;
          let shopid = 0;
          const productMatch = href.match(/\/product\/(\d+)\/(\d+)/);
          const slugMatch = href.match(/-i\.(\d+)\.(\d+)/);
          if (productMatch) {
            shopid = parseInt(productMatch[1], 10);
            itemid = parseInt(productMatch[2], 10);
          } else if (slugMatch) {
            shopid = parseInt(slugMatch[1], 10);
            itemid = parseInt(slugMatch[2], 10);
          }

          // Extract product name
          const nameEl = el.querySelector('[data-sqe="name"]') || el.querySelector('.ie3A\\+n') || el.querySelector('div[role="listitem"] div');
          const name = nameEl?.textContent?.trim() || '';

          // Extract image
          const imgEl = el.querySelector('img[src*="susercontent"]') || el.querySelector('img');
          const image = imgEl?.getAttribute('src') || '';

          // Extract price (visible text, formatted as ₫ amount)
          const priceEl = el.querySelector('[data-sqe="price"]') || el.querySelector('.ZEgDH9');
          const priceText = priceEl?.textContent?.replace(/[^\d.]/g, '') || '0';
          const price = parseFloat(priceText) || 0;

          // Extract discount
          const discountEl = el.querySelector('.percent') || el.querySelector('[data-sqe="discount"]');
          const discountText = discountEl?.textContent?.replace(/[^\d]/g, '') || '0';
          const discountPercent = parseInt(discountText, 10) || 0;

          // Extract sold count
          const soldEl = el.querySelector('.r6HknA') || el.querySelector('[data-sqe="sold"]');
          const soldText = soldEl?.textContent || '';
          let sold = 0;
          const soldMatch = soldText.match(/([\d,.]+)/);
          if (soldMatch) {
            sold = parseFloat(soldMatch[1].replace(/[,.]/g, '')) || 0;
            // Handle "k" suffix (e.g., "1,2k" = 1200)
            if (soldText.toLowerCase().includes('k')) {
              sold = sold * 1000;
            }
          }

          // Extract rating (star count from visual indicators)
          const ratingEl = el.querySelector('.shopee-rating-stars__lit');
          let ratingStar = 0;
          if (ratingEl) {
            const widthStyle = ratingEl.style.width;
            const widthPercent = parseFloat(widthStyle) || 0;
            ratingStar = Math.round((widthPercent / 100) * 5 * 10) / 10; // e.g., 96% → 4.8
          }

          const normalizedItem = {
            itemid,
            shopid,
            name,
            price,
            priceBeforeDiscount: price, // DOM doesn't reliably show original price
            discountPercent,
            image,
            sold,
            ratingStar,
            shopRating: 0,    // not available from DOM
            likedCount: 0,    // not available from DOM
            stock: 0,         // not available from DOM
            shopLocation: '', // not available from DOM fallback
            shopName: '',
            deliveryTime: '',
            variationsCount: 0,
            url: itemid ? `https://shopee.vn/product/${shopid}/${itemid}` : (href ? `https://shopee.vn${href}` : '')
          };

          if (normalizedItem.name && (normalizedItem.itemid || normalizedItem.url)) {
            if (isValidItem(normalizedItem, keyword)) {
              items.push(normalizedItem);
            }
          }
        } catch (elErr) {
          console.warn(`[DealSniper] DOM fallback: Error parsing element ${index}:`, elErr);
        }
      });

      console.log(`[DealSniper] DOM fallback extracted ${items.length} items.`);
    } catch (err) {
      console.error('[DealSniper] DOM fallback failed:', err);
    }

    return items;
  }

  // ──────────────────────────────────────────────
  // Fetch Engine (Subtask 1.3)
  // ──────────────────────────────────────────────

  /**
   * Build the Shopee search API URL with dynamic offset.
   */
  function buildSearchUrl(keyword, offset) {
    const params = new URLSearchParams({
      keyword: keyword,
      limit: FETCH_LIMIT.toString(),
      newest: offset.toString(),
      order: 'relevancy',
      by: 'relevancy',
      page_type: 'search'
    });
    return `${SEARCH_API}?${params.toString()}`;
  }

  /**
   * Execute request via XMLHttpRequest to bypass Shopee's fetch() wrapper.
   * Shopee monkey-patches window.fetch with security layers (sfu-stable, sws)
   * that intercept and can block/delay extension calls.
   * XHR is NOT wrapped by Shopee, so it goes through cleanly.
   */
  function fetchWithTimeout(url) {
    return new Promise((resolve) => {
      const xhr = new XMLHttpRequest();
      xhr.open('GET', url, true);
      xhr.timeout = TIMEOUT_MS;
      xhr.withCredentials = true; // send cookies (same as fetch credentials: 'include')
      xhr.setRequestHeader('Accept', 'application/json');
      xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');

      xhr.onload = function () {
        if (xhr.status >= 200 && xhr.status < 300) {
          try {
            const data = JSON.parse(xhr.responseText);
            resolve(data);
          } catch (e) {
            console.warn('[DealSniper] Failed to parse API response as JSON:', e);
            resolve(null);
          }
        } else {
          console.warn(`[DealSniper] XHR returned ${xhr.status}: ${xhr.statusText}`);
          resolve(null);
        }
      };

      xhr.ontimeout = function () {
        console.warn('[DealSniper] XHR timed out after', TIMEOUT_MS, 'ms');
        resolve(null);
      };

      xhr.onerror = function () {
        console.warn('[DealSniper] XHR network error');
        resolve(null);
      };

      xhr.send();
    });
  }

  /**
   * Fetch with one retry on failure.
   */
  async function fetchWithRetry(url) {
    let data = await fetchWithTimeout(url);
    if (data) return data;

    console.log('[DealSniper] Retrying (attempt 2/2)...');
    await delay(300);
    return await fetchWithTimeout(url);
  }

  /**
   * Main fetch loop. Sequential iterations with dynamic pagination.
   * Emits progress, complete, or error events back to content.js.
   */
  async function fetchDeals(keyword, maxIterations = 1) {
    console.log(`[DealSniper] Starting scan for "${keyword}" (Max Pages: ${maxIterations}, Offset: 0)`);
    let allItems = [];
    let offset = 0;
    let totalCount = 0;
    let usedDomFallback = false;

    for (let iteration = 0; iteration < maxIterations; iteration++) {
      const url = buildSearchUrl(keyword, offset);
      console.log(`[DealSniper] 🌐 Calling API: ${url}`);

      const data = await fetchWithRetry(url);

      // ISSUE-4 FIX: Differentiate between fetch failure and legitimately empty results
      if (!data) {
        // Fetch completely failed (network error, timeout after retry)
        console.warn(`[DealSniper] Fetch failed at iteration ${iteration + 1}. Triggering DOM fallback.`);

        const domItems = parseDOMFallback(keyword);
        if (domItems.length > 0) {
          const existingIds = new Set(allItems.map(i => i.itemid));
          const newDomItems = domItems.filter(i => !existingIds.has(i.itemid));
          allItems.push(...newDomItems);
          usedDomFallback = true;
        }

        if (allItems.length === 0) {
          emitError(keyword, 'All fetch attempts failed and DOM fallback returned no items.', []);
          return;
        }
        break;
      }

      if (!data.items || data.items.length === 0) {
        // API responded successfully but returned 0 items (legitimate empty / end of results)
        console.log(`[DealSniper] API returned 0 items at iteration ${iteration + 1}. No more results.`);
        break;
      }

      // Store total count from first response
      if (iteration === 0 && data.total_count) {
        totalCount = data.total_count;
      }

      // Log raw API output so user can see available fields
      if (iteration === 0 && data.items && data.items.length > 0) {
        console.log('[DealSniper] RAW SHOPEE API OUTPUT:', data.items[0]);
      }

      // Normalize items and filter out junk
      const normalized = data.items
        .map(normalizeItem)
        .filter(item => isValidItem(item, keyword));

      allItems.push(...normalized);

      // Dynamic offset: offset += actual items returned (never hardcoded)
      offset += data.items.length;

      // Emit progress
      emitProgress(allItems.length, iteration + 1);

      // Check if Shopee says there are no more results
      if (data.nomore === true) {
        console.log('[DealSniper] Shopee reports no more results. Stopping.');
        break;
      }

      // Randomized backoff between iterations (not after the last one)
      if (iteration < maxIterations - 1) {
        const backoffMs = randomBackoff();
        console.log(`[DealSniper] Backoff: ${Math.round(backoffMs)}ms before next iteration.`);
        await delay(backoffMs);
      }
    }

    // Emit completion
    console.log(`[DealSniper] Fetch complete: ${allItems.length} items collected.${usedDomFallback ? ' (includes DOM fallback)' : ''}`);
    emitComplete(keyword, allItems, totalCount);
  }

  // ──────────────────────────────────────────────
  // Event Emitters (Bridge → content.js)
  // ──────────────────────────────────────────────

  function emitProgress(itemsLoaded, iteration) {
    document.dispatchEvent(new CustomEvent(`${EVENT_PREFIX}fetch-progress`, {
      detail: { action: 'FETCH_PROGRESS', itemsLoaded, iteration }
    }));
  }

  function emitComplete(keyword, items, totalCount) {
    document.dispatchEvent(new CustomEvent(`${EVENT_PREFIX}fetch-complete`, {
      detail: { action: 'FETCH_COMPLETE', keyword, items, totalCount }
    }));
  }

  function emitError(keyword, error, partialItems) {
    document.dispatchEvent(new CustomEvent(`${EVENT_PREFIX}fetch-error`, {
      detail: { action: 'FETCH_ERROR', keyword, error, partialItems }
    }));
  }

  // ──────────────────────────────────────────────
  // Bridge Listener (receive from content.js)
  // ──────────────────────────────────────────────

  document.addEventListener(`${EVENT_PREFIX}fetch-request`, (event) => {
    const { action, keyword, pages } = event.detail || {};
    if (action === 'FETCH_DEALS' && keyword) {
      console.log(`[DealSniper] Received fetch request for "${keyword}" (Pages: ${pages || 1}).`);
      fetchDeals(keyword, pages || 1);
    }
  });

  // ──────────────────────────────────────────────
  // Initialization
  // ──────────────────────────────────────────────
  console.log('[DealSniper] Main world fetcher initialized on', location.hostname);

  // Signal readiness to content.js (ISSUE-3 FIX: handshake)
  document.dispatchEvent(new CustomEvent(`${EVENT_PREFIX}ready`, {
    detail: { status: 'ready' }
  }));

})();
